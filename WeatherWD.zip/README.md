# Android: 微度天气预报
使用微度天气API制作的天气预报安卓应用，感谢微度多年来提供免费、稳定的API。
### 主界面
![alt](preview.jpg)  
### 城市列表  
![alt](citylist.jpg)  
### 桌面小工具
![alt](AppWidget.jpg)  